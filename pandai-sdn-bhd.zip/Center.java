import java.util.Scanner;
import java.util.Collections;
import java.util.List;

class Center{
    // attributes
    String name;
    String phyAdd;
    String Headmaster;
    Tutor ListTutor[]= new Tutor[10];
    Student ListStudent[] = new Student[30];
    int currtutor=0;
    int currstud=0;
    String response = "";
    String response2 = "";
    Batch batch03 = new Batch();
    float avg=0, max=0, min=999,total=0;
    
    Scanner input= new Scanner(System.in);
    
    public void setCenterDetails(){ // set the detais of all attributes
            System.out.print("Enter center name:"); 
            this.name = input.nextLine();
            System.out.print("Enter physical address: "); 
            this.phyAdd = input.nextLine();
            System.out.print("Enter headmaster name:"); 
            this.Headmaster = input.nextLine();
            while (!response.equals("n") ){  
                this.addtutor(new Tutor(currtutor)); //set and create tutor 
                System.out.print("Enter new tutor? (y/n): "); 
                this.response = input.nextLine();
            }
            while (!response2.equals("n") ){
                this.addstudents(new Student(currstud)); //set and create new student
                System.out.print("Enter new students? (y/n): "); 
                this.response2 = input.nextLine();
            }
            System.out.println("Assigning Tutor to Students..."); //assign each student to one tutor
            while (this.getcurrtutor() != this.getcurrSt()){
                if (this.getcurrtutor() < this.getcurrSt()){
                    System.out.println("Error; not enough tutors to assign! \n Add Another Tutor");
                    this.addtutor(new Tutor(currtutor));
                }
                else if (this.getcurrtutor() > this.getcurrSt()){
                    System.out.println("Error; not enough students to assign! \nAdd another student");
                    this.addstudents(new Student(currstud));
                }
            }
            for (int i=0; i<this.getcurrtutor(); i++){ 
                this.ListStudent[i].AssTutor = ListTutor[i];
            }System.out.println("Assigned Completed\n");
            this.addStudInBatch();
            
    }
    void addtutor(Tutor n){ //method add new tutor + pass new tutor to constructor
        ListTutor[currtutor++] = n;
    }
    void addstudents(Student s){ //method add students + pass new students to constructor
        ListStudent[currstud++] = s;
    }
    int getcurrtutor(){ // get the current number of tutors
        return currtutor;
    }
    public int getcurrSt(){ // get the current of students
        return currstud;
    }
    public void addStudInBatch(){ //assign the students in one batch
        for (int x=0; x< getcurrSt(); x++){
            batch03.addBatchStud(ListStudent[x]);
        }
    }
    void dispReport(int z){ // display all info in a report
        System.out.print("\n\n-------Center "+(z+1)+" Report--------");
        System.out.print("\nCenter Name: "+ this.name +"\nPhysical Address: "+this.phyAdd+"\nHeadmaster: "+this.Headmaster);
        
        for (int i=0; i< this.getcurrtutor(); i++){ //display tutor details
            System.out.print("\n\n----Tutor #"+(i+1)+"----\nName: "+this.ListTutor[i].name+"\nID: "+this.ListTutor[i].ID+"\nAddress: "+
            this.ListTutor[i].address+"\nQualification: "+this.ListTutor[i].qualification+"\nYear Experience: "+
            this.ListTutor[i].yearExp+"\nDate Joined: "+this.ListTutor[i].datejoin+"\nYear Intake: "+this.ListTutor[i].yearIn);
        }
        for (int j=0; j<this.getcurrSt(); j++){ //display students details
            System.out.print("\n\n----Student #"+(j+1)+"----\nName: "+this.ListStudent[j].name+"\nIC: "+this.ListStudent[j].IC+
            "\nAddress: "+this.ListStudent[j].address+"\nSchool Name: "+this.ListStudent[j].schoolname);
        }
        for (int k=0; k<this.getcurrSt(); k++){ //find avg, max, min
            total+= this.ListStudent[k].avgEach;
            if (this.ListStudent[k].avgEach > max)
                max = this.ListStudent[k].avgEach;
            if (this.ListStudent[k].avgEach< min)
                min= this.ListStudent[k].avgEach;
        } avg = total/this.getcurrSt();
        //display avg, max, min
        System.out.println("\n\n----Performance------");
        System.out.println("Average Student Mark: "+ String.format("%.2f",avg));
        System.out.println("Highest (Average) Student Mark: "+ String.format("%.2f",max));
        System.out.println("Lowest (Average) Student Mark: "+ String.format("%.2f",min));
    }
}