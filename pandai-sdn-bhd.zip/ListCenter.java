import java.util.Scanner;

class ListCenter{
    Center ListCenter[] = new Center[10];
    int currsz =0;
    String response = "";
    Scanner input5= new Scanner (System.in);
    
    void addcenter(Center n){ //method add center into list
        ListCenter[currsz ++] = n;
    }
    public int getcurrsz(){ //get current size
        return currsz;
    }
    void deletecenter(){ //method delete any center from the list
        for (int i=0; i<currsz; i++){
            System.out.println((i+1)+". "+ListCenter[i].name);
        }
        System.out.print("Choose center (number) to delete (q to cancel):");
        response = input5.nextLine();
        while (!response.equals("q")){
            if (response.equals("1")){
                ListCenter[0] = null;
                System.out.println("Center 1 deleted *");
                //currsz = currsz - 1;
            }
            else if (response.equals("2")){
                ListCenter[1] = null;
                System.out.println("Center 2 deleted*");
                //currsz = currsz - 1;
            }
            System.out.print("delete another center? (q to quit) :");
            response = input5.nextLine();
        }
        }
}