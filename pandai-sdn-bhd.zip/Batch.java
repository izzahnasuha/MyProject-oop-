
import java.util.Scanner;
class Batch{
    Student liststud[] = new Student[5];
    int currsz=0;
    
    Scanner input3= new Scanner(System.in);
    
    void addBatchStud(Student i){ //method add students in a batch
        liststud[currsz++] = i;
    }
}