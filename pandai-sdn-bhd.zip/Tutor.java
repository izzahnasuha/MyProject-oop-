import java.util.Scanner;
class Tutor{
    
    String name;
    String ID;
    String address;
    String qualification;
    String yearExp;
    String datejoin;
    String yearIn;
    
    Scanner input2= new Scanner(System.in);
    
    Tutor (int x){ //constructor assign details for tutor
        System.out.print("\nEnter tutor"+(x+1)+" name:"); 
        this.name = input2.nextLine();
        System.out.print("Enter tutor"+(x+1)+" id: "); 
        this.ID = input2.nextLine();
        System.out.print("Enter tutor"+(x+1)+" address:"); 
        this.address = input2.nextLine();
        System.out.print("Enter qualification:"); 
        this.qualification = input2.nextLine();
        System.out.print("Enter year experience: "); 
        this.yearExp = input2.nextLine();
        System.out.print("Enter date joined:"); 
        this.datejoin = input2.nextLine();
        System.out.print("Enter year in:"); 
        this.yearIn = input2.nextLine();
    }
    
    
}