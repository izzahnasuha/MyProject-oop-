/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner input= new Scanner(System.in);
	    
		Center Elite = new Center(); //create center 1
		Elite.setCenterDetails(); //add the center details
		
		Center Advance = new Center(); //create center 2
		Advance.setCenterDetails(); // add details
		
		ListCenter list = new ListCenter(); //create Center List
		list.addcenter(Elite); // Add the centers into the list 
		list.addcenter(Advance);
		
		list.deletecenter(); //delete the center you want
		
		for (int i=0; i<list.getcurrsz(); i++){ //display overall report
		    if (list.ListCenter[i] == null){
		        System.out.println("\n\n----Center "+(i+1)+" has been deleted----");
		    }
		    else
		        list.ListCenter[i].dispReport(i);
		}
	}
}

