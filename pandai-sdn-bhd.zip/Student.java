
import java.util.Scanner;

class Student{
    Scanner obj= new Scanner(System.in);
    Scanner input4= new Scanner(System.in);
    
    String name;
    String IC;
    String address;
    String schoolname;
    float score[]= new float [3];
    Tutor AssTutor;
    float totalmark;
    float avgEach;
    Center obj2 = new Center();
    float totalavg=0,avg=0, max=0, min=999;
    
    Student(int x){ //constructor assign details of student
        System.out.print("\nEnter student"+(x+1)+" name:"); 
        this.name = input4.nextLine();
        System.out.print("Enter student"+(x+1)+" IC: "); 
        this.IC = input4.nextLine();
        System.out.print("Enter student"+(x+1)+" address:"); 
        this.address = input4.nextLine();
        System.out.print("Enter school name:"); 
        this.schoolname = input4.nextLine();
        this.addscore();
    }
    void addscore(){ //method add the students score of 3 subjects
        System.out.println("Enter marks for student-" + (this.getname()));
        for (int i=0; i<3; i++){
            System.out.print("Subject"+ (i+1)+": ");
            this.score[i] = obj.nextFloat();
            this.totalmark += this.score[i];
        }
        this.avgEach= (this.totalmark)/3;
        /*totalavg += (this.avgEach);
        avg= totalavg/ (obj2.getcurrSt()); //calculate avg
        if (this.avgEach > max){
            max = this.avgEach; //calculate max
        }
        if(this.avgEach < min){
            min = this.avgEach; //calculate min
        }*/
    }
    public String getname(){
        return this.name;
    }
}